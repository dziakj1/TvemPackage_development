## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(tvem)

## -----------------------------------------------------------------------------
set.seed(123);
the_data <- simulate_tvem_example(simulate_binary=TRUE);

## -----------------------------------------------------------------------------
print(head(the_data));
print(summary(the_data));

## -----------------------------------------------------------------------------
model1 <- tvem(data=the_data,
               formula=y~1,
               family=binomial(),
               id=subject_id,
               time=time);

## -----------------------------------------------------------------------------
model2 <- tvem(data=the_data,
               formula=y~x1,
               invar_effect=~x2,
               id=subject_id,
               family=binomial(),
               time=time);
print(model2);
plot(model2);

