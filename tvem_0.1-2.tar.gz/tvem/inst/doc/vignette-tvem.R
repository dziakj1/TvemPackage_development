## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(tvem)

## -----------------------------------------------------------------------------
set.seed(123);
the_data <- simulate_tvem_example();

## -----------------------------------------------------------------------------
print(head(the_data));
print(summary(the_data));

## -----------------------------------------------------------------------------
model1 <- tvem(data=the_data,
               formula=y~1,
               id=subject_id,
               time=time);

## -----------------------------------------------------------------------------
model1 <- tvem(data=the_data,
               formula=y~1,
               id=subject_id,
               num_knots=2,
               penalize=FALSE,
               time=time);

## ----fig.width=4,fig.height=4-------------------------------------------------
print(model1);
plot(model1);

## ----fig.width=4,fig.height=4-------------------------------------------------
model2 <- select_tvem(data=the_data,
                    formula = x1~1,
                    id=subject_id,
                    time=time);
print(model2);
plot(model2);

## ----fig.width=4,fig.height=4-------------------------------------------------
model3 <- tvem(data=the_data,
               formula=y~x1+x2,
               id=subject_id,
               time=time);
print(model3);
plot(model3);

## ----fig.width=4,fig.height=4-------------------------------------------------
model4 <- tvem(data=the_data,
               formula=y~x1,
               invar_effect=~x2,
               id=subject_id,
               time=time);
print(model4);
plot(model4);

## -----------------------------------------------------------------------------
set.seed(123);
the_data <- simulate_tvem_example(simulate_binary=TRUE);

## -----------------------------------------------------------------------------
model1 <- tvem(data=the_data,
               formula=y~1,
               family=binomial(),
               id=subject_id,
               time=time);

## -----------------------------------------------------------------------------
model2 <- tvem(data=the_data,
               formula=y~x1,
               invar_effect=~x2,
               id=subject_id,
               family=binomial(),
               time=time);
print(model2);
plot(model2);

## -----------------------------------------------------------------------------
plot(model2, exponentiate=TRUE);

